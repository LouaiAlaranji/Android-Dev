package com.example.todolist_lab01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class UpdateActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)


        val updateSave = findViewById<Button>(R.id.update_save);
        val updateToDoItem = intent.getIntExtra(CLICKED_ID, -1);
        val updateToDoId = toDoRepository.getToDoById(updateToDoItem);

        val title = findViewById<TextView>(R.id.update_title);
        title.setText(updateToDoId?.title);
        val content = findViewById<TextView>(R.id.update_content);
        content.setText(updateToDoId?.content);

        updateSave.setOnClickListener {
            val newTitle = findViewById<EditText>(R.id.update_title);
            val newContent = findViewById<TextView>(R.id.update_content);
            toDoRepository.updateToDoById(updateToDoItem, newTitle.toString(), newContent.toString() );

            startActivity (
                Intent(this, ViewToDoActivity::class.java).apply{
                    putExtra(CLICKED_ID, updateToDoItem);
                }
            )
        }

    }
}

