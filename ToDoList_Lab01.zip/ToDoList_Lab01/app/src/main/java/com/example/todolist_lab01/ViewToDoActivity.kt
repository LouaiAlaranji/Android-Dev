package com.example.todolist_lab01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

const val CLICKED_ID = "CLICKED_ID";

class ViewToDoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_to_do)

        // get the item ID clicked on from the Activity Main
        val toDoId = intent.getIntExtra(CLICKED_ID, -1);
        val itemGotten = toDoRepository.getToDoById(toDoId);

        // pass the item's Title and Context
        val title = findViewById<TextView>(R.id.to_do_title_text_view);
        title.text = itemGotten?.title;
        val content = findViewById<TextView>(R.id.to_do_content_text_view);
        content.text = itemGotten?.content;




        val deleteBtn = findViewById<Button>(R.id.deleteBtn);
        deleteBtn.setOnClickListener{
            AlertDialog.Builder(this)
                .setTitle("Delete ToDo")
                .setMessage("Do you really want to delete it?")
                .setPositiveButton(
                    "Yes"
                ) { dialog, whichButton ->
                    // Delete it.
                    toDoRepository.deleteToDoById(itemGotten!!.id);
                    startActivity (
                        Intent(this, MainActivity::class.java).apply{
                            putExtra(CLICKED_ID, toDoId);
                        }
                            )

                }.setNegativeButton(
                    "No"
                ) { dialog, whichButton ->
                    // Do not delete it.
                    startActivity (
                        Intent(this, MainActivity::class.java).apply {
                            putExtra(CLICKED_ID, toDoId);
                        })
                }.show()
        }


        val updateBtn = findViewById<Button>(R.id.updateBtn);
        updateBtn.setOnClickListener{
            startActivity (
                Intent(this, UpdateActivity::class.java).apply{
                    putExtra(CLICKED_ID, toDoId);
                }
            )
        }

    }
}