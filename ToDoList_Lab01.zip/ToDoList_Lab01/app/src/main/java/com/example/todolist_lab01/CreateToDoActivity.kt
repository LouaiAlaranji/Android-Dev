package com.example.todolist_lab01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class CreateToDoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_to_do)

        val title = findViewById<EditText>(
            R.id.create_title
        ).editableText.toString()

        val content = findViewById<EditText>(
            R.id.create_content
        ).editableText.toString()


        // click on saveBtn
         val saveBtn = findViewById<Button>(R.id.saveBtn);
        saveBtn.setOnClickListener {
            // Save changes
            val newItem = toDoRepository.addToDo(title, content);
            Intent(this, MainActivity::class.java).apply{
                putExtra(title, newItem);
            }
            finish();



    }


}



}
